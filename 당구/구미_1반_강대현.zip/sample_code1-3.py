import socket
import time
import math

# User and Game Server Information
NICKNAME = '파이썬'
HOST = '127.0.0.1'
PORT = 1447 # Do not modify

# predefined variables(Do not modify these values)
TABLE_WIDTH = 254
TABLE_HEIGHT = 124
NUMBER_OF_BALLS = 5
HOLES = [ [0, 0], [130, 0], [260, 0], [0, 130], [130, 130], [260, 130] ]

class Conn:
    def __init__(self):
        self.sock = socket.socket()
        print('Trying to Connect: ' + HOST + ':' + str(PORT))
        self.sock.connect((HOST, PORT))
        print('Connected: ' + HOST + ':' + str(PORT))
        send_data = '9901/' + NICKNAME
        self.sock.send(send_data.encode('utf-8'))
        print('Ready to play.\n--------------------')
    def request(self):
        self.sock.send('9902/9902'.encode())
        print('Received Data has been currupted, Resend Requested.')
    def receive(self):
        recv_data = (self.sock.recv(1024)).decode()
        print('Data Received: ' + recv_data)
        return recv_data
    def send(self, angle, power):
        merged_data = '%d/%d' % (angle, power)
        self.sock.send(merged_data.encode('utf-8'))
        print('Data Sent: ' + merged_data)
    def close(self):
        self.sock.close()

class GameData:
    def __init__(self):
        self.reset()
    def reset(self):
        self.balls = [[0, 0] for i in range(NUMBER_OF_BALLS)]
    def read(self, conn):
        recv_data = conn.receive()
        split_data = recv_data.split('/')
        idx = 0
        try:
            for i in range(NUMBER_OF_BALLS):
                for j in range(2):
                    self.balls[i][j] = int(split_data[idx])
                    idx += 1
        except:
            self.reset()
            conn.request()
            self.read(conn)
    def show(self):
        print('=== Arrays ===')
        for i in range(NUMBER_OF_BALLS):
            print('Ball%d: %d, %d' % (i, self.balls[i][0], self.balls[i][1]))
        print()

# 자신의 차례가 되어 게임을 진행해야 할 때 호출되는 Method
def play(conn, gameData):
    sx = gameData.balls[0][0]
    sy = gameData.balls[0][1]
    for i in range(1,5):
        nx = gameData.balls[i][0]
        ny = gameData.balls[i][1]
        if nx or ny:
            break


    if ny > sy:
        if nx>sx:
            case = 1
        else:
            case = 4
    else:
        if nx>sx:
            case = 2
        else:
            case = 3
    if case == 1:
        if sx>130 or nx>130:
            hx,hy = 257,127
        else:
            hx,hy = 130,127
    if case == 2:
        if sx>130 or nx> 130:
            hx,hy = 257,3
        else:
            hx,hy = 130,3
    if case == 3:
        if sx>130 and nx>130:
            hx,hy = 130,3
        else:
            hx,hy = 3,3
    if case == 4:
        if sx>130 and nx>130:
            hx,hy = 130,127
        else:
            hx,hy = 3,127
    dd = math.sqrt((ny - hy)**2 + (nx - hx)**2)

    print("sx,sy : ({},{}), nx,ny : ({},{}) , hx,hy : ({},{})".format(sx,sy,nx,ny,hx,hy))
    if case == 2:
        hy+=(sy-hy)*2
        ny+=(sy-ny)*2
    elif case == 3:
        hx+=(sx-hx)*2
        nx+=(sx-nx)*2
        hy+=(sy-hy)*2
        ny+=(sy-ny)*2
    elif case == 4:
        hx+=(sx-hx)*2
        nx+=(sx-nx)*2

    sin = math.sin
    a_2 = (sy-hy)**2 + (sx-hx)**2
    b_2 = (hy-ny)**2 + (hx-nx)**2
    c_2 = (ny-sy)**2 + (nx-sx)**2
    a = math.sqrt(a_2)
    b = math.sqrt(b_2)
    cosC = (a_2 + b_2 - c_2)/(2*a*b)
    C = math.acos(cosC)
    d_2 = (a*sin(C))**2 + ((b+7.5) - a*cosC)**2
    d = math.sqrt(d_2)
    cosS2 = (a_2 + d_2 - (b+7.5)**2)/(2*a*d)
    s2 = math.acos(cosS2)
    s1 = math.atan(abs(hx-sx)/abs(hy-sy))
    print("case: {}".format(case))

    seta=s1+s2

    mind = math.sqrt((ny-sy)**2 + (nx-sx)**2)
    print("mind : {} , d : {}".format(mind,dd))
    print("distance : {}".format(mind+dd))
    if mind + dd >200:
        power = 150
    elif mind + dd > 160:
        power = 130
    elif mind + dd > 120:
        power = 100
    elif mind +dd > 80:
        power = 82
    elif mind +dd > 60:
        power = 74
    elif mind + dd > 40:
        power = 61
    else:
        power = 46

    print("power : {}".format(power))

    if sx==77 and sy==9 and nx==122 and ny==17:
        hx = 257
        hy = 127


    if case == 1:
        if (hy-sy)/(hx-sx)<(ny-sy)/(nx-sx):
            angle = (s1-s2)*57.2958
        else:
            angle = seta*57.2958
    elif case == 2:
        if (hy-sy)/(hx-sx)<(ny-sy)/(nx-sx):
            angle = 180 - (s1-s2)*57.2958
        else:
            angle= 180 - seta*57.2958
    elif case == 3:
        if (hy-sy)/(hx-sx)<(ny-sy)/(nx-sx):
            angle = 180 + (s1-s2)*57.2958
        else:
            angle= 180 + seta*57.2958
    elif case == 4:
        if (hy-sy)/(hx-sx)<(ny-sy)/(nx-sx):
            angle = 360 - (s1-s2)*57.2958
        else:
            angle= 360 - seta*57.2958



    ######################################################################################
    # 주어진 정보를 바탕으로 샷을 할 방향과 세기를 결정해서 angle, power 값으로 지정 #
    ######################################################################################
    #3-1
    print(sx,sy,nx,ny)
    if sx == 65 and sy == 65 and nx==115 and ny==110:
        power = 178

    # 3-2
    if sx == 143 and sy == 121 and nx == 166 and ny==137:
        power = 138
        angle = 120

    # 1-1
    if sx == 65 and sy ==65 and nx == 250 and ny == 120:
        angle = 75
        power = 100

    print(angle)
    conn.send(angle, power)


def main():
    conn = Conn()
    gameData = GameData()
    while True:
        gameData.read(conn)
        gameData.show()
        play(conn, gameData)        
    conn.close()
    print('Connection Closed')

if __name__ == '__main__':
    main()
